# -*- coding: utf-8 -*-
"""
/***************************************************************************
 ComboboxLayer
                                 A QGIS plugin
 Load layer to ComboBox
                              -------------------
        begin                : 2014-09-28
        git sha              : $Format:%H$
        copyright            : (C) 2014 by combo.inc
        email                : combo@box.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
from PyQt4.QtCore import QSettings, QTranslator, qVersion, QCoreApplication
from PyQt4.QtGui import QAction, QIcon
# Initialize Qt resources from file resources.py
import resources_rc
# Import the code for the dialog
from qgis.core import *
from qgis.gui import QgsMessageBar, QgsMapToolEmitPoint
from combobox_layer_dialog import ComboboxLayerDialog
from new_lib import LayerOperation, EquiDistLibrary
import os.path


class ComboboxLayer:
    """QGIS Plugin Implementation."""

    def __init__(self, iface):
        """Constructor.

        :param iface: An interface instance that will be passed to this class
            which provides the hook by which you can manipulate the QGIS
            application at run time.
        :type iface: QgsInterface
        """
        # Save reference to the QGIS interface
        self.iface = iface
        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        # initialize locale
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            'ComboboxLayer_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)

            if qVersion() > '4.3.3':
                QCoreApplication.installTranslator(self.translator)
        # deflare container
        #self.point_list_a=[]
        #self.point_list_b=[]
        #self.feat_list_a = []
        #self.feat_list_b = []
        # Create the dialog (after translation) and keep reference
        self.dlg = ComboboxLayerDialog(self.iface)                      #pass iface to the dialog
        self.layOpt = LayerOperation()

        # Declare instance attributes
        self.actions = []
        self.menu = self.tr(u'&ComboBox Layer')
        # TODO: We are going to let the user set this up in a future iteration
        self.toolbar = self.iface.addToolBar(u'ComboboxLayer')
        self.toolbar.setObjectName(u'ComboboxLayer')

    # noinspection PyMethodMayBeStatic
    def tr(self, message):
        """Get the translation for a string using Qt translation API.

        We implement this ourselves since we do not inherit QObject.

        :param message: String for translation.
        :type message: str, QString

        :returns: Translated version of message.
        :rtype: QString
        """
        # noinspection PyTypeChecker,PyArgumentList,PyCallByClass
        return QCoreApplication.translate('ComboboxLayer', message)


    def add_action(
        self,
        icon_path,
        text,
        callback,
        enabled_flag=True,
        add_to_menu=True,
        add_to_toolbar=True,
        status_tip=None,
        whats_this=None,
        parent=None):
        """Add a toolbar icon to the InaSAFE toolbar.

        :param icon_path: Path to the icon for this action. Can be a resource
            path (e.g. ':/plugins/foo/bar.png') or a normal file system path.
        :type icon_path: str

        :param text: Text that should be shown in menu items for this action.
        :type text: str

        :param callback: Function to be called when the action is triggered.
        :type callback: function

        :param enabled_flag: A flag indicating if the action should be enabled
            by default. Defaults to True.
        :type enabled_flag: bool

        :param add_to_menu: Flag indicating whether the action should also
            be added to the menu. Defaults to True.
        :type add_to_menu: bool

        :param add_to_toolbar: Flag indicating whether the action should also
            be added to the toolbar. Defaults to True.
        :type add_to_toolbar: bool

        :param status_tip: Optional text to show in a popup when mouse pointer
            hovers over the action.
        :type status_tip: str

        :param parent: Parent widget for the new action. Defaults None.
        :type parent: QWidget

        :param whats_this: Optional text to show in the status bar when the
            mouse pointer hovers over the action.

        :returns: The action that was created. Note that the action is also
            added to self.actions list.
        :rtype: QAction
        """

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)

        if whats_this is not None:
            action.setWhatsThis(whats_this)

        if add_to_toolbar:
            self.toolbar.addAction(action)

        if add_to_menu:
            self.iface.addPluginToMenu(
                self.menu,
                action)

        self.actions.append(action)

        return action

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""

        icon_path = ':/plugins/ComboboxLayer/icon.png'
        self.add_action(
            icon_path,
            text=self.tr(u'ComboBox Layer'),
            callback=self.run,
            parent=self.iface.mainWindow())


    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        for action in self.actions:
            self.iface.removePluginMenu(
                self.tr(u'&ComboBox Layer'),
                action)
            self.iface.removeToolBarIcon(action)
    def clickedStartA(self,point, button):
        self.start_a = self.clickTool.toMapCoordinates(self.clickTool.toCanvasCoordinates(point))
        self.iface.messageBar().pushMessage('Info','Success',level=QgsMessageBar.INFO,duration=1)
        self.dlg.lineEdit_sa.setText("%s,%s"%(str(self.start_a.x()),str(self.start_a.y())))
        self.clickTool.deactivate()
        self.dlg.show()
    def pressedStartA(self):
        self.clickTool = QgsMapToolEmitPoint(self.iface.mapCanvas())
        self.iface.messageBar().pushMessage('Info','Input Start Point 1',level=QgsMessageBar.INFO,duration=1)
        self.iface.mapCanvas().setMapTool(self.clickTool)
        self.clickTool.canvasClicked.connect(self.clickedStartA)
        self.dlg.hide()
    def clickedStartB(self,point, button):
        self.start_b = self.clickTool.toMapCoordinates(self.clickTool.toCanvasCoordinates(point))
        self.iface.messageBar().pushMessage('Info','Success',level=QgsMessageBar.INFO,duration=1)
        self.dlg.lineEdit_sb.setText("%s,%s"%(str(self.start_b.x()),str(self.start_b.y())))
        self.clickTool.deactivate()
        self.dlg.show()
    def pressedStartB(self):
        self.clickTool = QgsMapToolEmitPoint(self.iface.mapCanvas())
        self.iface.messageBar().pushMessage('Info','Input Start Point B',level=QgsMessageBar.INFO,duration=1)
        self.iface.mapCanvas().setMapTool(self.clickTool)
        self.clickTool.canvasClicked.connect(self.clickedStartB)
        self.dlg.hide()
    def clickedEndA(self,point, button):
        self.end_a = self.clickTool.toMapCoordinates(self.clickTool.toCanvasCoordinates(point))
        self.iface.messageBar().pushMessage('Info','Success',level=QgsMessageBar.INFO,duration=1)
        self.dlg.lineEdit_ea.setText("%s,%s"%(str(self.end_a.x()),str(self.end_a.y())))
        self.clickTool.deactivate()
        self.dlg.show()
    def pressedEndA(self):
        self.clickTool = QgsMapToolEmitPoint(self.iface.mapCanvas())
        self.iface.messageBar().pushMessage('Info','Input End Point A',level=QgsMessageBar.INFO,duration=1)
        self.iface.mapCanvas().setMapTool(self.clickTool)
        self.clickTool.canvasClicked.connect(self.clickedEndA)
        self.dlg.hide()
    def clickedEndB(self,point, button):
        self.end_b = self.clickTool.toMapCoordinates(self.clickTool.toCanvasCoordinates(point))
        self.iface.messageBar().pushMessage('Info','Success',level=QgsMessageBar.INFO,duration=1)
        self.dlg.lineEdit_eb.setText("%s,%s"%(str(self.end_b.x()),str(self.end_b.y())))
        self.clickTool.deactivate()
        self.dlg.show()
    def pressedEndB(self):
        self.clickTool = QgsMapToolEmitPoint(self.iface.mapCanvas())
        self.iface.messageBar().pushMessage('Info','Input End Point B',level=QgsMessageBar.INFO,duration=1)
        self.iface.mapCanvas().setMapTool(self.clickTool)
        self.clickTool.canvasClicked.connect(self.clickedEndB)
        self.dlg.hide()
    def deploy_opp(self):
        #self.iface.messageBar().clearWidgets()
        self.layer_a = self.dlg.inputLayerA.itemData(self.dlg.inputLayerA.currentIndex())
        self.layer_b = self.dlg.inputLayerB.itemData(self.dlg.inputLayerB.currentIndex())
        #self.iface.messageBar().pushMessage('Info','layer 1 =%s, layer 2 =%s' %(str(layer_a.name()),str(layer_b.name())),level=QgsMessageBar.INFO)
        point_layer_a = self.layOpt.lineToPoint(self.layer_a,"A")
        #point_layer_a.startEditing()
        #point_layer_a.commitChanges()
        point_layer_b = self.layOpt.lineToPoint(self.layer_b,"B")
        #point_layer_b.startEditing()
        #point_layer_b.commitChanges()
        feat_list_a=[]
        feat_list_b=[]
        for feat in point_layer_a.getFeatures():
            #self.point_list_a.append(feat.geometry().asPoint())
            feat_list_a.append(feat)
        for feat in point_layer_b.getFeatures():
            #self.point_list_b.append(feat.geometry().asPoint())
            feat_list_b.append(feat)
        #self.dlg.textBrowser.clear()
        # clear everytime the dialog loaded
        #self.dlg.textBrowser.append(str(self.layer_a.name()))
        #self.dlg.textBrowser.append(str(self.layer_b.name()))
        # input points are self.start_a, self.start_b, self.end_a, self.end_b
        interval_ = self.dlg.opp_intv.value()
        libs = EquiDistLibrary(point_layer_a,point_layer_b,interval_)
        # find nearest point in point_layer_a and point_layer_b to their corresponding start point and end point
        start_feat_a = libs.nearestFeat(self.start_a,feat_list_a)
        end_feat_a = libs.nearestFeat(self.end_a,feat_list_a)
        start_feat_b = libs.nearestFeat(self.start_b,feat_list_b)
        end_feat_b = libs.nearestFeat(self.end_b,feat_list_b)
        start_point_a= start_feat_a.geometry().asPoint()
        start_point_b= start_feat_b.geometry().asPoint()
        end_point_a= end_feat_a.geometry().asPoint()
        end_point_b= end_feat_b.geometry().asPoint()
        #------------------
        #self.dlg.textBrowser.append(str(start_point_a))
        #self.dlg.textBrowser.append(str(end_point_a))
        m1 = libs.findMid(start_point_a,start_point_b)
        #self.dlg.textBrowser.append(str(m1))
        #self.dlg.textBrowser.append(str(start_point_b))
        #self.dlg.textBrowser.append(str(end_point_b))
        m2 = libs.findMid(end_point_a,end_point_b)
        #self.dlg.textBrowser.append(str(m2))
        #-------------------------------------------
        # main function. return list of
        #libs.deploy(self.feat_list_a,self.feat_list_b,start_point_a,start_point_b,end_point_a,end_point_b)
        final_res, construction_line = libs.deploy(feat_list_a,feat_list_b,start_point_a,start_point_b,end_point_a,end_point_b)
        self.layOpt.addPointF(final_res)
        self.layOpt.pointlayerToLine(final_res)
        self.layOpt.addLine_FList(construction_line)
    def deploy_adj(self):
        layer_a = self.dlg.inputLayerA.itemData(self.dlg.inputLayerA.currentIndex())
        layer_b = self.dlg.inputLayerB.itemData(self.dlg.inputLayerB.currentIndex())
        line_a = layer_a.getF

    # adjacent ------------------------------------------------------------------------------
    def adj_clickedStartA(self, point, button):
        self.adj_start_a = self.clickTool.toMapCoordinates(self.clickTool.toCanvasCoordinates(point))
        self.iface.messageBar().pushMessage('Info','Success',level=QgsMessageBar.INFO,duration=1)
        self.dlg.adj_lineEditA.setText("%s,%s"%(str(self.adj_start_a.x()),str(self.adj_start_a.y())))
        self.clickTool.deactivate()
        self.dlg.show()
    def adj_pressedStartA(self):
        self.clickTool = QgsMapToolEmitPoint(self.iface.mapCanvas())
        self.iface.messageBar().pushMessage('Info','Input Start Point A',level=QgsMessageBar.INFO,duration=1)
        self.iface.mapCanvas().setMapTool(self.clickTool)
        self.clickTool.canvasClicked.connect(self.adj_clickedStartA)
        self.dlg.hide()

    def adj_clickedStartB(self, point, button):
        self.adj_start_b = self.clickTool.toMapCoordinates(self.clickTool.toCanvasCoordinates(point))
        self.iface.messageBar().pushMessage('Info','Success',level=QgsMessageBar.INFO,duration=1)
        self.dlg.adj_lineEditB.setText("%s,%s"%(str(self.adj_start_b.x()),str(self.adj_start_b.y())))
        self.clickTool.deactivate()
        self.dlg.show()
    def adj_pressedStartB(self):
        self.clickTool = QgsMapToolEmitPoint(self.iface.mapCanvas())
        self.iface.messageBar().pushMessage('Info','Input Start Point B',level=QgsMessageBar.INFO,duration=1)
        self.iface.mapCanvas().setMapTool(self.clickTool)
        self.clickTool.canvasClicked.connect(self.adj_clickedStartB)
        self.dlg.hide()

    def seaSide(self, point, button):
        self.sea_side = self.clickTool.toMapCoordinates(self.clickTool.toCanvasCoordinates(point))
        self.iface.messageBar().pushMessage('Info','Success',level=QgsMessageBar.INFO,duration=1)
        self.clickTool.deactivate()
        self.dlg.show()
    def pressed_seaSide(self):
        self.clickTool = QgsMapToolEmitPoint(self.iface.mapCanvas())
        self.iface.messageBar().pushMessage('Info','Input Sea Side Point',level=QgsMessageBar.INFO,duration=1)
        self.iface.mapCanvas().setMapTool(self.clickTool)
        self.clickTool.canvasClicked.connect(self.seaSide)
        self.dlg.hide()

    def run(self):
        """Run method that performs all the real work"""
        # show the dialog
        #self.clickTool = QgsMapToolEmitPoint(self.iface.mapCanvas())
        #self.clickTool.canvasClicked.connect(self.clickedStartA)
        # clear everytime the dialog loaded
        self.dlg.inputLayerA.clear()
        self.dlg.inputLayerB.clear()
        # connect Opposite case button
        self.dlg.opp_btnStartA.pressed.connect(self.pressedStartA)
        self.dlg.opp_btnStartB.pressed.connect(self.pressedStartB)
        self.dlg.opp_btnEndA.pressed.connect(self.pressedEndA)
        self.dlg.opp_btnEndB.pressed.connect(self.pressedEndB)
        self.dlg.opp_btnRun.pressed.connect(self.deploy_opp)
        # connect Adjacent case button
        self.dlg.adj_btnStartA.pressed.connect(self.adj_pressedStartA)
        self.dlg.adj_btnStartB.pressed.connect(self.adj_pressedStartB)
        self.dlg.btnSeaSide.pressed.connect(self.pressed_seaSide)
        self.dlg.adj_btnRun.pressed.connect(self.deploy_adj)
        # load all Layer from mapCanvas
        layers = QgsMapLayerRegistry.instance().mapLayers().values()
        if len(layers)<1:
            self.iface.messageBar().pushMessage('Error','No layer loaded',level=QgsMessageBar.CRITICAL,duration=3)
        else:
        #input layer loaded to comboBox
            for layer in layers:
                if layer.type() == QgsMapLayer.VectorLayer and layer.geometryType() == 1:
                    self.dlg.inputLayerA.addItem(layer.name(),layer)
                    self.dlg.inputLayerB.addItem(layer.name(),layer)
            self.dlg.show()
            # Run the dialog event loop
            result = self.dlg.exec_()
            # See if OK was pressed
            if result:
                # Do something useful here - delete the line containing pass and
                # substitute with your code.
                pass
